﻿namespace UI_elements
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.RoomDropDown = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.NameDropDown = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.ServiceBox = new System.Windows.Forms.ComboBox();
            this.ServiceBox3 = new System.Windows.Forms.ComboBox();
            this.ServiceBox2 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.CreditBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.TotalBox = new System.Windows.Forms.TextBox();
            this.AddServicesBox = new System.Windows.Forms.TextBox();
            this.RoomRateBox = new System.Windows.Forms.TextBox();
            this.ExitButton = new System.Windows.Forms.Button();
            this.CheckOutButton = new System.Windows.Forms.Button();
            this.CancelButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // RoomDropDown
            // 
            this.RoomDropDown.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RoomDropDown.Location = new System.Drawing.Point(214, 90);
            this.RoomDropDown.Name = "RoomDropDown";
            this.RoomDropDown.Size = new System.Drawing.Size(139, 31);
            this.RoomDropDown.TabIndex = 40;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(20, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(166, 24);
            this.label4.TabIndex = 39;
            this.label4.Text = "Room Number/s";
            // 
            // NameDropDown
            // 
            this.NameDropDown.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameDropDown.FormattingEnabled = true;
            this.NameDropDown.Location = new System.Drawing.Point(214, 30);
            this.NameDropDown.Name = "NameDropDown";
            this.NameDropDown.Size = new System.Drawing.Size(257, 32);
            this.NameDropDown.TabIndex = 38;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(53, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 24);
            this.label1.TabIndex = 37;
            this.label1.Text = "Guest Name";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(20, 199);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(181, 24);
            this.label2.TabIndex = 41;
            this.label2.Text = "Additional service";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(20, 263);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(181, 24);
            this.label3.TabIndex = 42;
            this.label3.Text = "Additional service";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(20, 327);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(181, 24);
            this.label5.TabIndex = 43;
            this.label5.Text = "Additional service";
            // 
            // ServiceBox
            // 
            this.ServiceBox.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ServiceBox.FormattingEnabled = true;
            this.ServiceBox.Items.AddRange(new object[] {
            "Cable-TV",
            "PBX Calling",
            "Room Service"});
            this.ServiceBox.Location = new System.Drawing.Point(214, 196);
            this.ServiceBox.Name = "ServiceBox";
            this.ServiceBox.Size = new System.Drawing.Size(199, 32);
            this.ServiceBox.TabIndex = 44;
            // 
            // ServiceBox3
            // 
            this.ServiceBox3.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ServiceBox3.FormattingEnabled = true;
            this.ServiceBox3.Items.AddRange(new object[] {
            "Cable-TV",
            "PBX Calling",
            "Room Service"});
            this.ServiceBox3.Location = new System.Drawing.Point(214, 324);
            this.ServiceBox3.Name = "ServiceBox3";
            this.ServiceBox3.Size = new System.Drawing.Size(199, 32);
            this.ServiceBox3.TabIndex = 45;
            // 
            // ServiceBox2
            // 
            this.ServiceBox2.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ServiceBox2.FormattingEnabled = true;
            this.ServiceBox2.Items.AddRange(new object[] {
            "Cable-TV",
            "PBX Calling",
            "Room Service"});
            this.ServiceBox2.Location = new System.Drawing.Point(214, 260);
            this.ServiceBox2.Name = "ServiceBox2";
            this.ServiceBox2.Size = new System.Drawing.Size(199, 32);
            this.ServiceBox2.TabIndex = 46;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(20, 439);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(200, 24);
            this.label6.TabIndex = 47;
            this.label6.Text = "Credit Card Number";
            // 
            // CreditBox
            // 
            this.CreditBox.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CreditBox.Location = new System.Drawing.Point(226, 436);
            this.CreditBox.Name = "CreditBox";
            this.CreditBox.Size = new System.Drawing.Size(199, 31);
            this.CreditBox.TabIndex = 48;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(561, 36);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(114, 24);
            this.label7.TabIndex = 49;
            this.label7.Text = "Room Rate";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(489, 96);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(194, 24);
            this.label8.TabIndex = 50;
            this.label8.Text = "Additional Services";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(566, 160);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(107, 24);
            this.label9.TabIndex = 51;
            this.label9.Text = "Total Cost";
            // 
            // TotalBox
            // 
            this.TotalBox.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalBox.Location = new System.Drawing.Point(694, 157);
            this.TotalBox.Name = "TotalBox";
            this.TotalBox.Size = new System.Drawing.Size(139, 31);
            this.TotalBox.TabIndex = 52;
            // 
            // AddServicesBox
            // 
            this.AddServicesBox.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddServicesBox.Location = new System.Drawing.Point(694, 93);
            this.AddServicesBox.Name = "AddServicesBox";
            this.AddServicesBox.Size = new System.Drawing.Size(139, 31);
            this.AddServicesBox.TabIndex = 53;
            // 
            // RoomRateBox
            // 
            this.RoomRateBox.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RoomRateBox.Location = new System.Drawing.Point(694, 33);
            this.RoomRateBox.Name = "RoomRateBox";
            this.RoomRateBox.Size = new System.Drawing.Size(139, 31);
            this.RoomRateBox.TabIndex = 54;
            // 
            // ExitButton
            // 
            this.ExitButton.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExitButton.Location = new System.Drawing.Point(743, 429);
            this.ExitButton.Name = "ExitButton";
            this.ExitButton.Size = new System.Drawing.Size(90, 41);
            this.ExitButton.TabIndex = 57;
            this.ExitButton.Text = "Exit";
            this.ExitButton.UseVisualStyleBackColor = true;
            this.ExitButton.Click += new System.EventHandler(this.ExitButton_Click);
            // 
            // CheckOutButton
            // 
            this.CheckOutButton.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CheckOutButton.Location = new System.Drawing.Point(475, 429);
            this.CheckOutButton.Name = "CheckOutButton";
            this.CheckOutButton.Size = new System.Drawing.Size(125, 41);
            this.CheckOutButton.TabIndex = 56;
            this.CheckOutButton.Text = "Check-Out";
            this.CheckOutButton.UseVisualStyleBackColor = true;
            // 
            // CancelButton
            // 
            this.CancelButton.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CancelButton.Location = new System.Drawing.Point(622, 429);
            this.CancelButton.Name = "CancelButton";
            this.CancelButton.Size = new System.Drawing.Size(90, 41);
            this.CancelButton.TabIndex = 55;
            this.CancelButton.Text = "Cancel";
            this.CancelButton.UseVisualStyleBackColor = true;
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::UI_elements.Properties.Resources.runnyrem_LfqmND_hym8_unsplash1;
            this.ClientSize = new System.Drawing.Size(870, 513);
            this.Controls.Add(this.ExitButton);
            this.Controls.Add(this.CheckOutButton);
            this.Controls.Add(this.CancelButton);
            this.Controls.Add(this.RoomRateBox);
            this.Controls.Add(this.AddServicesBox);
            this.Controls.Add(this.TotalBox);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.CreditBox);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.ServiceBox2);
            this.Controls.Add(this.ServiceBox3);
            this.Controls.Add(this.ServiceBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.RoomDropDown);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.NameDropDown);
            this.Controls.Add(this.label1);
            this.Name = "Form4";
            this.Text = "Check-Out And Billing";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox RoomDropDown;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox NameDropDown;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox ServiceBox;
        private System.Windows.Forms.ComboBox ServiceBox3;
        private System.Windows.Forms.ComboBox ServiceBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox CreditBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox TotalBox;
        private System.Windows.Forms.TextBox AddServicesBox;
        private System.Windows.Forms.TextBox RoomRateBox;
        private System.Windows.Forms.Button ExitButton;
        private System.Windows.Forms.Button CheckOutButton;
        private System.Windows.Forms.Button CancelButton;
    }
}